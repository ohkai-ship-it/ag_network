# Agent Handoff

Repo is the shared truth. Update:
- CURRENT_STATE.md (now)
- NEXT_PR_PROMPT.md (next)
- DECISIONS.md (why)
- COMPLETION_SUMMARIES/... (what happened)

Rule: any contract change must update docs + tests.
