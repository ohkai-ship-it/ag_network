# Completion Summaries

One file per PR: `PR4_COMPLETION_SUMMARY.md`.

Include:
- Summary (bullets)
- Backlog IDs closed
- Invariants enforced
- Tests (ruff/pytest)
- Evidence (rg/AST checks)
