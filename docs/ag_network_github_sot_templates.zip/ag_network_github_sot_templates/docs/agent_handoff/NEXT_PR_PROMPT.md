# NEXT_PR_PROMPT

Paste this into Opus.

## PR title

## Scope
✅
❌

## Invariants
-
-

## Steps
1)
2)

## Tests
-

## Acceptance
-
