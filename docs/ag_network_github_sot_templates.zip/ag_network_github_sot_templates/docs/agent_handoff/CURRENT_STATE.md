# CURRENT_STATE

## Branch/version
- main:
- current branch:
- version/tag:

## Objective
- Hardening: workspace isolation, no global fallbacks, truthful CLI.

## Done
- PR1:
- PR2:
- PR3:

## Expected skips
- (tests requiring API keys)

## Next PR
- PR#:
- Backlog IDs:
- Acceptance:
