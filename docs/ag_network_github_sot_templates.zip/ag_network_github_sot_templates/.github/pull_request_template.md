## Scope
- Backlog IDs:
- Invariants enforced:

## What changed
-

## Tests
- ruff:
- pytest:
- New/updated tests:

## Evidence
- No global fallbacks:
- Workspace isolation:
- CLI truthfulness:
