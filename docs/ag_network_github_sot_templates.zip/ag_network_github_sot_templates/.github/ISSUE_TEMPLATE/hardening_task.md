---
name: Hardening task
about: Scoped hardening item tied to FINDINGS_BACKLOG
labels: [hardening]
---

## Backlog ID(s)
-

## Problem
-

## Fix
-

## Acceptance
- [ ]
- [ ]

## Tests
- [ ]
